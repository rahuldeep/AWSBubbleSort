# AWSBubbleSort
Bubble sort on AWS
